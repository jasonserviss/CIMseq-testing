source("/home/martin/pancreas/RNAseq_2/RNAseq_functs.R")

counts <- load.count.data("/home/martin/correlative/GP5d/CIRM_master_expression_count_table.tsv", mincount=1e5)[[1]]
counts.ercc <- load.count.data("/home/martin/correlative/GP5d/CIRM_master_expression_count_table.tsv", mincount=1e5)[[2]]

o <- grep('10001029', colnames(counts))
counts <- counts[,o]
counts.ercc <- counts.ercc[,o]
counts.log <- norm.log.counts(counts)

good.cells <- counts.log['ACTB',] > get.cutoff.lognorm(counts.log)
table(good.cells)
counts.log <- counts.log[,good.cells]
counts <- counts[,good.cells]
counts.ercc <- counts.ercc[,good.cells]
colnames(counts)
dbl <- rep("Singlet", length=length(colnames(counts)))
dbl[grepl('1000102901', colnames(counts))] <- "Doublet"
dbl <- grepl('1000102901', colnames(counts))
frac.ercc <- colSums(counts.ercc) / (colSums(counts.ercc)+colSums(counts))
ps <- boxplot(split(frac.ercc, dbl), ylab="Fraction ERCC reads")

points(frac.ercc ~ jitter(as.numeric(as.factor(dbl)), factor=0.4), main="Fraction ERCC in singlets/doublets", pch=19, cex=0.6, col="brown")

plot(frac.ercc ~ jitter(as.numeric(as.factor(dbl)), factor=1), main="Fraction ERCC in singlets/doublets", pch=19, cex=1, col="black")
dev2bitmap("ERCC_fraction.pdf", type="pdfwrite")

a <- sapply(split(frac.ercc, dbl), median)
a[[1]]/a[[2]]
a[[1]]/0.1

library(paralell)
mode.fail.d <- calc.mode.fail.dist(counts, n.cores=8)


# targets: vector, ngenes long
# values: matrix, ngenes x ncells long
# result: char vector: ncells long color list
col.from.targets <- function(targets, values) {
    v <- t(apply(values, 1, function(x) {(x-min(x))/(max(x)-min(x))}))
    fractions <- apply(v, 2, function(x) {x/sum(x)})
    fractions[is.nan(fractions)] <- 1
    targets.rgb <- col2rgb(targets)
    res <- vector("character", length=length(targets))
    for(i in 1:(dim(values)[2])) {
        mytarget.rgb <- t(apply(targets.rgb, 1, function(x) {x * v[,i]}))
        mytarget.rgb <- rowSums(t(apply(mytarget.rgb, 1, function(x) {x * fractions[,i]})))
        res[i] <- rgb(red=mytarget.rgb['red']/255, green=mytarget.rgb['green']/255, blue=mytarget.rgb['blue']/255)
    }
    res
}

library(RColorBrewer)
celltype.genes <- c("THY1", "INS", "GCG", "NEUROG3")
celltype.genes <- c("INS", "GCG")
celltype.genes <- c("THY1", "INS", "GCG", "NEUROG3", "PROM1", "FLT1")
celltype.genes <- c("INS", "GCG", "NEUROG3")
celltype.genes <- c("INS", "GCG", "SST")
celltype.genes <- c("THY1", "NEUROG3")
celltype.genes <- "EPCAM"
my.pal <- brewer.pal(9, "Set1")[c(1:5, 8)]
my.pal <- brewer.pal(length(celltype.genes), "Set3")
targets <- my.pal[1:length(celltype.genes) ]
values <- counts.log[celltype.genes,]
cols <- col.from.targets(targets, values)
plot(my.tsne.2d[dbl == "Doublet",], col=cols[dbl=="Doublet"], pch=19)
plot(my.tsne.2d, col=(dbl=="Doublet")+1, pch=19)
plot(my.tsne.2d, col=cols, pch=19 ,cex=2, type='n')
points(my.tsne.2d, col=c("lightgrey", "black")[(dbl=="Doublet")+1], cex=2.5, lwd=3)
points(my.tsne.2d[which(dbl=='Doublet')[1:2],], col=c("green", "blue"))
points(my.tsne.2d, col=cols, pch=19 ,cex=2)
legend("topleft", legend=celltype.genes, fill=my.pal)
dev2bitmap("tSNE_doublets.pdf", type="pdfwrite")

plot(counts.log['INS',] ~ counts.log['GCG',], col=as.factor(dbl == "Doublet"))
plot(counts.log['INS',] ~ counts.log['THY1',], col=as.factor(dbl == "Doublet"))
plot(counts.log['GCG',] ~ counts.log['THY1',], col=as.factor(dbl == "Doublet"))
plot(counts.log['INS',] ~ counts.log['NEUROG3',], col=as.factor(dbl == "Doublet"))
plot(counts.log['INS',] ~ counts.log['EPCAM',], col=as.factor(dbl == "Doublet"))
plot(counts.log['NEUROG3',] ~ counts.log['THY1',], col=as.factor(dbl == "Doublet"))
plot(counts.log['FLT1',] ~ counts.log['THY1',], col=as.factor(dbl == "Doublet"))
plot(counts.log['EPCAM',] ~ counts.log['THY1',], col=as.factor(dbl == "Doublet"))
plot(counts.log['PROM1',] ~ counts.log['THY1',], col=as.factor(dbl == "Doublet"))
plot(counts.log['PROM1',] ~ counts.log['FLT1',], col=as.factor(dbl == "Doublet"))
library(rgl)
plot3d(counts.log['THY1',], counts.log['FLT1',],counts.log['EPCAM',],  col=c("black", "red")[(dbl == "Doublet")+1], size=10)
plot3d(counts.log['THY1',], counts.log['FLT1',],counts.log['INS',],  col=c("black", "red")[(dbl == "Doublet")+1], size=10)
col <- jet.colors(101)[rank(frac.ercc)/length(frac.ercc)*100]
plot3d(counts.log['THY1',], counts.log['FLT1',],counts.log['INS',],  col=col, size=10)


plot(counts.log['PROM1',] ~ counts.log['INS',], col=as.factor(dbl == "Doublet"))
dev2bitmap("coexpression_of_RNA_in_REDdoublets_BLACKsinglets.pdf", type="pdfwrite", width=9, height=6)
par(mfrow=c(2,3))


# Try some optimization
cell.types <- counts.log[,dbl=='Singlet']
fractions <- rep(1.0/(dim(cell.types)[2]), (dim(cell.types)[2]))

make.synthetic.slice <- function(cell.types, fractions) {
#    fractions <- fractions-min(fractions)
    fractions <- fractions/sum(fractions)
    apply(cell.types, 1, function(x) {log2(sum(x*fractions))})
}

dist.to.slice <- function(fractions, cell.types, slice) {
    a <- make.synthetic.slice(cell.types, fractions)
    cost <- sum((a - slice)^2)
    cost
}

library(optimx)
optim.res <- optimx(par=fractions, fn=dist.to.slice, gr=NULL, cell.types=2^cell.types, slice=2^counts.log[,which(dbl=='Doublet')[1]], method="Nelder-Mead")
optim.res <- optimx(par=fractions, fn=dist.to.slice, gr=NULL, cell.types=cell.types, slice=slices.log[,18], method="bobyqa", lower=0.0, upper=1.0)

optim.res.all.2 <- lapply(1:(dim(slices.log)[2]), function(i) {
    optimx(par=fractions, fn=dist.to.slice, gr=NULL, cell.types=cell.types, slice=slices.log[,i], method=c("L-BFGS-B"), lower=0.0, upper=1.0)
})

# Find best 4 cells by brute force. 

dist.to.cell <- function(mixture, cell.types) {
    synth.cell <- rowSums(cell.types)
    synth.cell <- synth.cell/sum(synth.cell)*1022673
    cost <- sum((synth.cell - mixture)^2)
    cost
}

doublet.counts <- 2^counts.log[,dbl=="Doublet"]
singlet.counts <- 2^counts.log[,dbl=="Singlet"]


o <- c(1, 40, 35, 50)
dist.to.cell(doublet.counts[,1], singlet.counts[,o])
dsts <- lapply(1:100000, function(x) {
#    rcells <- sample(1:(dim(singlet.counts)[2]), sample(2:4, 1))
    rcells <- sample(1:(dim(singlet.counts)[2]), 2)
    return(list(rcells, dist.to.cell(doublet.counts[,1], singlet.counts[,rcells])))
})
o <- order(sapply(dsts, function(x) {x[[2]]}))
# Correct answer: THY1 + FLT1:
plot(doublet.counts[celltype.genes,1])
barplot(pp)
barplot(rowSums(singlet.counts[celltype.genes,dsts[[o[[3]]]][[1]]]))
